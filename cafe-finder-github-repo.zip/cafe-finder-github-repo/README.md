# Café Finder App

A sample public repository for the Café Finder App course project.

## User Story Issue Template

The GitHub issue template is located at:
`.github/ISSUE_TEMPLATE/user-story.md`

## Example user story

As a café customer, I want to filter cafés by location and rating, so that I can quickly find a café that suits my preferences.
