---
name: User Story
about: Create a user story for the Café Finder App
title: "USER STORY: "
labels: "user story"
assignees: ""
---

## User Story
As a [type of user], I want [a feature or action], so that [benefit or value].

## Acceptance Criteria
- [ ] Given [context], when [action], then [expected result].
- [ ] Given [context], when [action], then [expected result].

## Notes
Add any relevant design links, dependencies, or technical details here.
